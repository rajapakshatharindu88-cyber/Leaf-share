package com.leaf.share

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning

class MainActivity : ComponentActivity() {
    private val vm: LeafViewModel by viewModels()

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            vm.directAllowed = hasDirectPermission()
            vm.startDiscovery()
        }

    private val filePicker =
        registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
            if (uris.isNotEmpty()) vm.addFiles(uris)
        }

    private val mediaPicker =
        registerForActivityResult(ActivityResultContracts.PickMultipleVisualMedia()) { uris ->
            if (uris.isNotEmpty()) vm.addFiles(uris)
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        enableEdgeToEdge()
        super.onCreate(savedInstanceState)
        vm.directAllowed = hasDirectPermission()
        setContent {
            LeafTheme {
                LeafApp(
                    vm = vm,
                    onPickFiles = { filePicker.launch(arrayOf("*/*")) },
                    onPickMedia = {
                        mediaPicker.launch(
                            PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageAndVideo)
                        )
                    },
                    onScan = { scanQr() }
                )
            }
        }
        if (!hasDirectPermission()) {
            permissionLauncher.launch(arrayOf(directPermission()))
        } else {
            vm.startDiscovery()
        }
    }

    override fun onResume() {
        super.onResume()
        vm.directAllowed = hasDirectPermission()
    }

    private fun directPermission(): String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.NEARBY_WIFI_DEVICES
        else Manifest.permission.ACCESS_FINE_LOCATION

    private fun hasDirectPermission(): Boolean =
        ContextCompat.checkSelfPermission(this, directPermission()) == PackageManager.PERMISSION_GRANTED

    private fun scanQr() {
        val options = GmsBarcodeScannerOptions.Builder()
            .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
            .build()
        GmsBarcodeScanning.getClient(this, options)
            .startScan()
            .addOnSuccessListener { barcode ->
                val raw = barcode.rawValue
                if (raw != null) vm.onQrScanned(raw) else vm.message = "The QR code was empty."
            }
            .addOnFailureListener { e ->
                vm.message = "QR scanner not available: ${e.message ?: "unknown error"}"
            }
    }
}
