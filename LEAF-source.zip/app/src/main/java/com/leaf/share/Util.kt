package com.leaf.share

import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.DateFormat
import java.util.Date
import java.util.Locale

fun formatSize(bytes: Long): String {
    if (bytes < 1000) return "$bytes B"
    val units = arrayOf("KB", "MB", "GB", "TB")
    var v = bytes.toDouble()
    var i = -1
    while (v >= 1000 && i < units.size - 1) {
        v /= 1000.0
        i++
    }
    return String.format(Locale.US, "%.1f %s", v, units[i])
}

fun formatSpeed(bytesPerSec: Double): String =
    String.format(Locale.US, "%.1f MB/s", bytesPerSec / 1_000_000.0)

fun formatEta(seconds: Long): String {
    if (seconds < 0) return "calculating…"
    if (seconds < 60) return "${seconds}s left"
    val m = seconds / 60
    val s = seconds % 60
    if (m < 60) return "${m}m ${s}s left"
    return "${m / 60}h ${m % 60}m left"
}

fun formatTime(millis: Long): String =
    DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(millis))

fun sanitizeName(raw: String): String {
    var s = raw.substringAfterLast('/').substringAfterLast('\\')
    s = s.replace(Regex("[\\\\/:*?\"<>|\\p{Cntrl}]"), "_").trim().trimStart('.')
    if (s.isEmpty()) s = "file"
    return s.take(200)
}

object LocalNet {
    /** IPv4 addresses of this phone on Wi-Fi / hotspot / Wi-Fi Direct, best first. */
    fun ipv4Hosts(): List<String> {
        val found = ArrayList<Pair<Int, String>>()
        try {
            val interfaces = NetworkInterface.getNetworkInterfaces() ?: return emptyList()
            for (ni in interfaces.toList()) {
                if (!ni.isUp || ni.isLoopback) continue
                val n = ni.name.lowercase(Locale.US)
                if (n.startsWith("rmnet") || n.startsWith("ccmni") || n.startsWith("v4-") || n.startsWith("dummy")) continue
                val rank = when {
                    n.startsWith("wlan") || n.startsWith("swlan") || n.startsWith("ap") -> 0
                    n.startsWith("p2p") -> 1
                    else -> 2
                }
                for (a in ni.inetAddresses.toList()) {
                    if (a is Inet4Address && !a.isLoopbackAddress && a.isSiteLocalAddress) {
                        val h = a.hostAddress ?: continue
                        found.add(rank to h)
                    }
                }
            }
        } catch (_: Exception) {
        }
        return found.sortedBy { it.first }.map { it.second }.distinct()
    }
}
