package com.leaf.share

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WpsInfo
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pManager
import android.os.Looper
import androidx.core.content.ContextCompat

/**
 * Finds other LEAF phones on the same Wi-Fi network or hotspot using mDNS / DNS-SD (NsdManager)
 * and advertises this phone while it is on the Receive screen.
 */
class LanDiscovery(ctx: Context, private val onChange: (List<Peer>) -> Unit) {
    private val nsd = ctx.applicationContext.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val found = LinkedHashMap<String, Peer>()
    private val queue = ArrayDeque<NsdServiceInfo>()
    private val lock = Any()
    private var resolving = false
    private var reg: NsdManager.RegistrationListener? = null
    private var disc: NsdManager.DiscoveryListener? = null

    @Volatile
    private var ownName: String? = null

    fun register(deviceName: String, port: Int) {
        unregister()
        val info = NsdServiceInfo()
        info.serviceName = "LEAF-" + deviceName.take(40)
        info.serviceType = SERVICE_TYPE
        info.setPort(port)
        ownName = info.serviceName
        val l = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(i: NsdServiceInfo) {
                ownName = i.serviceName
            }

            override fun onRegistrationFailed(i: NsdServiceInfo, errorCode: Int) {}
            override fun onServiceUnregistered(i: NsdServiceInfo) {}
            override fun onUnregistrationFailed(i: NsdServiceInfo, errorCode: Int) {}
        }
        reg = l
        try {
            nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, l)
        } catch (_: Exception) {
            reg = null
        }
    }

    fun unregister() {
        val l = reg ?: return
        reg = null
        try {
            nsd.unregisterService(l)
        } catch (_: Exception) {
        }
    }

    fun startDiscovery() {
        if (disc != null) return
        val l = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(serviceType: String) {}
            override fun onServiceFound(s: NsdServiceInfo) {
                if (!s.serviceType.contains("_leaf._tcp")) return
                if (s.serviceName == ownName) return
                synchronized(lock) { queue.addLast(s) }
                pump()
            }

            override fun onServiceLost(s: NsdServiceInfo) {
                synchronized(lock) { found.remove(s.serviceName) }
                publish()
            }

            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {
                disc = null
            }

            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
        }
        disc = l
        try {
            nsd.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, l)
        } catch (_: Exception) {
            disc = null
        }
    }

    fun stopDiscovery() {
        val l = disc ?: return
        disc = null
        try {
            nsd.stopServiceDiscovery(l)
        } catch (_: Exception) {
        }
        synchronized(lock) {
            found.clear()
            queue.clear()
        }
        publish()
    }

    fun restartDiscovery() {
        stopDiscovery()
        startDiscovery()
    }

    fun shutdown() {
        unregister()
        stopDiscovery()
    }

    @Suppress("DEPRECATION")
    private fun pump() {
        val next = synchronized(lock) {
            if (resolving) null else queue.removeFirstOrNull()?.also { resolving = true }
        } ?: return
        try {
            nsd.resolveService(next, object : NsdManager.ResolveListener {
                override fun onResolveFailed(i: NsdServiceInfo, errorCode: Int) {
                    done()
                }

                override fun onServiceResolved(i: NsdServiceInfo) {
                    val host = i.host?.hostAddress
                    if (host != null && i.serviceName != ownName) {
                        synchronized(lock) {
                            found[i.serviceName] = Peer(
                                id = "lan:" + i.serviceName,
                                name = i.serviceName.removePrefix("LEAF-"),
                                hosts = listOf(host),
                                port = i.port,
                                transport = Transport.LAN
                            )
                        }
                        publish()
                    }
                    done()
                }
            })
        } catch (_: Exception) {
            done()
        }
    }

    private fun done() {
        synchronized(lock) { resolving = false }
        pump()
    }

    private fun publish() {
        val list = synchronized(lock) { found.values.toList() }
        onChange(list)
    }

    companion object {
        const val SERVICE_TYPE = "_leaf._tcp."
    }
}

/**
 * Wi-Fi Direct (Wi-Fi P2P). The receiving phone creates a group; the sending phone discovers it,
 * joins it, and then connects to the group owner's address. This path needs the user to accept
 * Android's own "invitation" prompt on the receiving phone.
 */
@SuppressLint("MissingPermission")
class WifiDirect(
    private val ctx: Context,
    private val onPeers: (List<Peer>) -> Unit,
    private val onConnected: (groupOwnerIp: String?, isGroupOwner: Boolean) -> Unit,
    private val onStatus: (String) -> Unit
) {
    private val appCtx = ctx.applicationContext
    private val manager = appCtx.getSystemService(Context.WIFI_P2P_SERVICE) as? WifiP2pManager
    private var channel: WifiP2pManager.Channel? = null
    private var registered = false

    val supported: Boolean get() = manager != null

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, intent: Intent?) {
            val m = manager ?: return
            val ch = channel ?: return
            when (intent?.action) {
                WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                    try {
                        m.requestPeers(ch) { list ->
                            onPeers(
                                list.deviceList.map {
                                    Peer(
                                        id = it.deviceAddress,
                                        name = it.deviceName ?: it.deviceAddress,
                                        hosts = emptyList(),
                                        port = LEAF_PORT,
                                        transport = Transport.WIFI_DIRECT
                                    )
                                }
                            )
                        }
                    } catch (_: Exception) {
                    }
                }

                WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                    try {
                        m.requestConnectionInfo(ch) { info ->
                            if (info != null && info.groupFormed) {
                                onConnected(info.groupOwnerAddress?.hostAddress, info.isGroupOwner)
                            }
                        }
                    } catch (_: Exception) {
                    }
                }
            }
        }
    }

    fun start() {
        val m = manager ?: return
        if (channel == null) channel = m.initialize(appCtx, Looper.getMainLooper(), null)
        if (!registered) {
            val filter = IntentFilter().apply {
                addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
                addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
            }
            ContextCompat.registerReceiver(appCtx, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
            registered = true
        }
    }

    fun discover() {
        val m = manager ?: return
        val ch = channel ?: return
        try {
            m.discoverPeers(ch, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {}
                override fun onFailure(reason: Int) {
                    onStatus("Wi-Fi Direct search failed (code $reason). Is Wi-Fi on?")
                }
            })
        } catch (_: Exception) {
        }
    }

    /** Receiver: become the group owner so a sender can join. */
    fun hostGroup() {
        val m = manager ?: return
        val ch = channel ?: return
        try {
            m.removeGroup(ch, object : WifiP2pManager.ActionListener {
                override fun onSuccess() = create()
                override fun onFailure(reason: Int) = create()
            })
        } catch (_: Exception) {
            create()
        }
    }

    private fun create() {
        val m = manager ?: return
        val ch = channel ?: return
        try {
            m.createGroup(ch, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    onStatus("Wi-Fi Direct group ready")
                    discover()
                }

                override fun onFailure(reason: Int) {
                    onStatus("Wi-Fi Direct group not available (code $reason)")
                }
            })
        } catch (_: Exception) {
        }
    }

    /** Sender: ask a discovered peer to let us join. */
    @Suppress("DEPRECATION")
    fun connect(peer: Peer, onFail: (Int) -> Unit) {
        val m = manager ?: return
        val ch = channel ?: return
        val config = WifiP2pConfig()
        config.deviceAddress = peer.id
        config.groupOwnerIntent = 0
        config.wps.setup = WpsInfo.PBC
        try {
            m.connect(ch, config, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {}
                override fun onFailure(reason: Int) = onFail(reason)
            })
        } catch (_: Exception) {
            onFail(-1)
        }
    }

    fun cancelConnect() {
        val m = manager ?: return
        val ch = channel ?: return
        try {
            m.cancelConnect(ch, null)
        } catch (_: Exception) {
        }
    }

    fun stopGroup() {
        val m = manager ?: return
        val ch = channel ?: return
        try {
            m.removeGroup(ch, null)
        } catch (_: Exception) {
        }
    }

    fun shutdown() {
        val m = manager
        val ch = channel
        if (m != null && ch != null) {
            try {
                m.stopPeerDiscovery(ch, null)
            } catch (_: Exception) {
            }
            try {
                m.removeGroup(ch, null)
            } catch (_: Exception) {
            }
        }
        if (registered) {
            try {
                appCtx.unregisterReceiver(receiver)
            } catch (_: Exception) {
            }
            registered = false
        }
    }
}
