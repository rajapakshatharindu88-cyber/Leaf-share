# 🍃 LEAF — fast, private file sharing between Android phones

LEAF sends photos, videos, documents, APKs and any other files directly from one Android phone to another.
No account, no cloud server, no internet needed for the transfer itself.

* **Premium white + emerald design** with a leaf-inspired look
* **Send / Receive** with automatic discovery of nearby phones
* **QR-code pairing** and a 6-digit code
* **Encrypted** connection (AES-256-GCM) and **SHA-256 verification** of every file
* **Live progress, MB/s speed and time remaining**, cancel at any time
* **Receiver must accept** before anything is saved
* **Big files are fine** – files are streamed, never loaded fully into memory

---

## Get your APK in 5 minutes (no coding, no Android Studio)

```
 ZIP you downloaded ──► your GitHub repository ──► GitHub builds it ──► you download LEAF.apk
      (extract)            (upload the files)       (Actions tab)        (install on phone)
```

### Option A — using a computer (easiest, folders upload in one go)

1. **Download and extract** `LEAF-Android-GitHub-Ready.zip`.
2. Go to <https://github.com/new>, give the repository a name (for example `leaf`), leave everything else as it is, and click **Create repository**.
3. On the new repository page click **uploading an existing file**.
4. Open the extracted folder, select **everything inside it** (including the hidden `.github` folder — switch on *Show hidden files* in your file manager: Windows → View → Hidden items, Mac → press `Cmd+Shift+.`) and drag it into the browser.
   The files must sit at the **top level** of the repository (you should see `app`, `gradle`, `gradlew`, `settings.gradle.kts` … and `.github`, not one extra folder around them).
5. Scroll down, keep **Commit directly to the `main` branch**, click **Commit changes**.
6. Open the **Actions** tab. A run called **Build LEAF APK** starts by itself. (If it does not: click *Build LEAF APK* → **Run workflow**.)
7. Wait 5–10 minutes until the run shows a green ✓. A red ✗ means the build failed — see *If the build fails* below.
8. Open the finished run and scroll to **Artifacts** at the bottom. Click **LEAF-Android-APK** to download it.
9. **The download is a ZIP file** (GitHub always wraps artifacts in a ZIP). Extract it – inside is `app-debug.apk`.
10. Copy the APK to your Android phone (or do these steps directly on the phone), tap it, allow *Install unknown apps* when Android asks, and install. Open **LEAF** and allow the permission it asks for.

### Option B — using only an Android phone

GitHub's website cannot upload *folders* from a phone browser, so this path uploads one ZIP and one small text file instead:

1. Extract `LEAF-Android-GitHub-Ready.zip` with the **Files** app (tap the ZIP → *Extract*), then open the folder **`phone-upload`**. It contains `LEAF-source.zip` and `android-build.yml`.
2. In Chrome open <https://github.com/new>, name the repository, tap **Create repository**.
3. Tap **uploading an existing file**, choose **`LEAF-source.zip`** (do *not* extract it), then **Commit changes**.
4. Tap **Add file → Create new file**. In the name box type exactly `.github/workflows/android-build.yml` (typing the `/` creates the folders).
   Open `android-build.yml` from the `phone-upload` folder in any text viewer, **select all, copy**, paste it into the big GitHub text box, then tap **Commit changes**.
5. Continue with steps 6–10 of Option A. The workflow unpacks `LEAF-source.zip` for you before building.

---

## Using LEAF

**Receiving phone:** tap **RECEIVE**. It shows a 6-digit code and a QR code. Keep the screen open.

**Sending phone:** tap **SEND** → choose files (or photos & videos) → tap the receiving phone in the list (or **Scan receiver's QR code**) → enter the code if you did not scan → **Send**.

The receiving phone shows who is sending what and asks **Accept / Decline**. Accepted files are saved in **Downloads/LEAF**.

### Connections
| Situation | What LEAF uses |
|---|---|
| Both phones on the same Wi-Fi, or one phone's hotspot | Automatic discovery (mDNS) + direct TCP – usually the fastest option |
| No Wi-Fi network available | **Wi-Fi Direct**: the receiver creates a group, the sender joins it. Android shows the receiver an invitation prompt to accept. |

Speed is **measured live** and shown in MB/s. LEAF does not promise any particular speed – it depends on both phones, the Wi-Fi band (5 GHz is much faster than 2.4 GHz) and distance.

---

## How it works (technical summary)

```
Sender                                              Receiver
  │── 16-byte random salt ───────────────────────────►│
  │◄────────────────────────── 16-byte random salt ───│
  │  key = PBKDF2-HMAC-SHA256(6-digit code, both salts, 30 000 rounds)
  │══ AES-256-GCM encrypted frames (64 KB) from here ═│
  │── hello: name, file list ────────────────────────►│  wrong code → decryption fails → closed
  │◄──────────────────────── accept / decline / full ─│  user must tap Accept
  │── file bytes + SHA-256 ──────────────────────────►│  hash compared, bad file deleted
  │◄───────────────────────────── verified / failed ──│
```

* Source: `app/src/main/java/com/leaf/share/`
  `Engine.kt` (transfer protocol), `SecureStreams.kt` (encryption), `Discovery.kt` (Wi-Fi network + Wi-Fi Direct discovery), `LeafViewModel.kt` (app logic), `Ui.kt` (Jetpack Compose screens).
* Kotlin 2.0.20, Jetpack Compose (Material 3), Android Gradle Plugin 8.5.2, Gradle 8.9, JDK 17, minSdk 29 (Android 10), targetSdk 34.
* Third-party libraries: ZXing core (draws the QR code), Google code scanner (reads QR codes).

## Honest limitations

* **Not run on real phones by the author of this package.** The encryption/framing code was compiled and tested on a PC, but the Android app as a whole (UI, discovery, Wi-Fi Direct, file saving) could not be built or run in the environment that generated this project, because it has no Android SDK or access to Google's build servers. The project follows standard, stable APIs and versions, but **a first-build error or a rough edge on a specific phone model is possible.** If the GitHub build fails, open the failed run → download **LEAF-build-logs** (or read the log) and share the first red error line to get it fixed.
* **Wi-Fi Direct is best-effort.** Behaviour differs a lot between phone brands. If it does not work, use a shared Wi-Fi network or one phone's hotspot (select the same network on both).
* Public/guest Wi-Fi often blocks devices from seeing each other ("client isolation"). Use a hotspot or home Wi-Fi.
* The 6-digit code protects against casual interception; it is not a replacement for a full password-authenticated key exchange. The receiver generates a fresh code each time it opens the Receive screen and after 5 wrong attempts.
* The receiver must keep LEAF open on screen; there is no background service in this first version.
* Android 10 or newer is required (files are saved through MediaStore, which needs no storage permission). The QR scanner needs Google Play services.
* Android 12 and older need **Location** switched on for Wi-Fi Direct discovery (Android requirement; LEAF never uses your location).

## Security & signing

The APK from this workflow is a **debug build**, signed automatically with the standard Android debug key. That is fine for installing on your own phone. A public release (Play Store or sharing widely) needs a **separately created and securely stored release keystore**, normally kept in GitHub *Secrets*, never committed to the repository. No keys or secrets are included here.

## If the build fails

1. Open **Actions** → the red run → the failed step shows the error. 
2. Download **LEAF-build-logs** at the bottom of the run for the full log.
3. Make sure the repository root contains `app/`, `gradle/`, `gradlew`, `settings.gradle.kts`, `build.gradle.kts` (Option A) or `LEAF-source.zip` (Option B).

## License

MIT – see `LICENSE`.
